function validate(){
    var name = document.getElementById("name").value;
    var subject = document.getElementById("subject").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;
    var error_message = document.getElementById("error_message");
    var text;
    
    error_message.style.padding= "10px";
    if(name.length<6){
       text ="Please enter valid Name";
       error_message.innerHTML=text;
       return false;
    }
    error_message.style.padding= "10px";
    if(subject.length<10){
        text ="Please enter correct subject";
        error_message.innerHTML=text;
        return false;
    }
    error_message.style.padding= "10px";
    if(isNaN(phone) || phone.length != 10){
        text ="Please enter correct phone number";
        error_message.innerHTML=text;
        return false;
    }
       
    error_message.style.padding= "10px";
    if(email.indexOf("@")== -1 || email.length < 6){
        text ="Please enter valid email";
        error_message.innerHTML=text;
        return false;
    }
    error_message.style.padding= "10px";
    if(message.length<=140){
        text ="Please enter more than 140 char";
        error_message.innerHTML=text;
        return false;
    } 
alert("Successfull")
return true;
}